<?php
/*
Plugin Name: Genesis Simple Sidebars
Plugin URI: http://www.studiopress.com/plugins/simple-sidebars

Description: Genesis Simple Sidebars allows you to easily create and use new sidebar widget areas.

Author: StudioPress
Author URI: http://www.studiopress.com/

Version: 2.1.0

Text Domain: genesis-simple-sidebars
Domain Path: /languages/

License: GNU General Public License v2.0 (or later)
License URI: http://www.opensource.org/licenses/gpl-license.php
*/

require_once( plugin_dir_path( __FILE__ ) . 'genesis-simple-sidebars.php' );
