<?php

/**
 * Dummy function for backward compatibility. Outputs the primary sidebar.
 *
 * @since 0.9.0
 */
function ss_do_sidebar() {
	genesis_do_sidebar();
}

/**
 * Dummy function for backward compatibility. Outputs the secondary sidebar.
 *
 * @since 0.9.0
 */
function ss_do_sidebar_alt() {
	genesis_do_sidebar_alt();
}
