# eWAY Payment Gateway #

Integrate some popular WordPress plugins with the eWAY credit card payment gateway

* [Home](https://shop.webaware.com.au/downloads/eway-payment-gateway/)
* [GitHub](https://github.com/webaware/eway-payment-gateway)
* [Readme](https://github.com/webaware/eway-payment-gateway/blob/master/readme.txt)
* [Changelog](https://github.com/webaware/eway-payment-gateway/blob/master/changelog.md)
* [Download](https://wordpress.org/plugins/eway-payment-gateway/)
* [Documentation](https://wordpress.org/plugins/eway-payment-gateway/faq/)
* [Support](https://wordpress.org/support/plugin/eway-payment-gateway)
* [Translate](https://translate.wordpress.org/projects/wp-plugins/eway-payment-gateway)
* [Donate](https://shop.webaware.com.au/donations/?donation_for=eWAY+Payment+Gateway)
